/*
 * SQIntMap.C
 */
#include "SQIntMap.h"

using namespace std;

ClassImp(SQIntMap)
