#ifdef __CINT__

#pragma link C++ class SQHitMap_v1+;

#endif /* __CINT__ */
