#ifdef __CINT__

#pragma link C++ class SQTrackVector+;

#endif /* __CINT__ */
