#ifdef __CINT__

#pragma link C++ class SQHit+;

#endif /* __CINT__ */
