#ifdef __CINT__

#pragma link C++ class SQHitMap+;

#endif /* __CINT__ */
