#ifdef __CINT__

#pragma link C++ class SQTrack_v1+;

#endif /* __CINT__ */
