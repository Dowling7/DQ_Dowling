#ifdef __CINT__

#pragma link C++ class SQMCEvent+;

#endif /* __CINT__ */
