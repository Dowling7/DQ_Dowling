#ifdef __CINT__

#pragma link C++ class SQSpillMap+;

#endif /* __CINT__ */
