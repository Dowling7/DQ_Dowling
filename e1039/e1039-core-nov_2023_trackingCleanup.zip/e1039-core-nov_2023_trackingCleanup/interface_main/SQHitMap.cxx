/*
 * SQHitMap.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw@nmsu.edu
 */



#include "SQHitMap.h"

#include "SQHit.h"

using namespace std;

ClassImp(SQHitMap)
