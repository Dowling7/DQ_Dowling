/*
 * SQHit.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw
 */

#include "SQHit.h"

using namespace std;

ClassImp(SQHit);


