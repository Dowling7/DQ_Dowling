#ifdef __CINT__

#pragma link C++ class SQEvent+;

#endif /* __CINT__ */
