#include "SQTrack.h"
using namespace std;
ClassImp(SQTrack)

//void SQTrack::identify(std::ostream& os = std::cout) const
//{
//  cout << "---SQTrack::identify: abstract base-------------------" << endl;
//}

