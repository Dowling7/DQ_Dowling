#include "SQDimuon.h"
using namespace std;
ClassImp(SQDimuon)

//void SQDimuon::identify(std::ostream& os = std::cout) const
//{
//  cout << "---SQDimuon::identify: abstract base-------------------" << endl;
//}

