/*
 * SQSlowCont.C
 */
#include "SQSlowCont.h"

using namespace std;

ClassImp(SQSlowCont);
