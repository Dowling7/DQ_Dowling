///SQParamDeco.cxx
#include "SQParamDeco.h"

using namespace std;

ClassImp(SQParamDeco);


