#ifdef __CINT__

#pragma link C++ class SQSpillMap_v1+;

#endif /* __CINT__ */
