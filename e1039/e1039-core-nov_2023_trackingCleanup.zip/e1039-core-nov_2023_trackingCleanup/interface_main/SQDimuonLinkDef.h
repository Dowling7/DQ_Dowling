#ifdef __CINT__

#pragma link C++ class SQDimuon+;

#endif /* __CINT__ */
