#ifdef __CINT__

#pragma link C++ class SQStringMap+;

#endif /* __CINT__ */
