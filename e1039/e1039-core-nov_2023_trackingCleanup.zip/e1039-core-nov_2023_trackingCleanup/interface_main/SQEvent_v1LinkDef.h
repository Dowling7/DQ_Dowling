#ifdef __CINT__

#pragma link C++ class SQEvent_v1+;

#endif /* __CINT__ */
