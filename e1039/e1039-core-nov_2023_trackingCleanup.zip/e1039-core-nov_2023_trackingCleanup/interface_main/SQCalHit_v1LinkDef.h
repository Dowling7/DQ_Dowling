#ifdef __CINT__

#pragma link C++ class SQCalHit_v1+;

#endif /* __CINT__ */