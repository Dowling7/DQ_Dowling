#ifdef __CINT__

#pragma link C++ class SQIntMap_v1+;

#endif /* __CINT__ */
