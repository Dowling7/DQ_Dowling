#ifdef __CINT__

#pragma link C++ class SQEvent_v2+;

#endif /* __CINT__ */
