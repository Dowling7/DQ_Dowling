#ifdef __CINT__

#pragma link C++ class SQParamDeco+;

#endif /* __CINT__ */
