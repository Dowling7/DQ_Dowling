/*
 * SQHitVector.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw@nmsu.edu
 */



#include "SQHitVector.h"

#include "SQHit.h"

using namespace std;

ClassImp(SQHitVector)
