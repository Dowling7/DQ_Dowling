/*
 * SQScaler.C
 */
#include "SQScaler.h"

using namespace std;

ClassImp(SQScaler);
