#ifdef __CINT__

#pragma link C++ class SQScaler+;

#endif /* __CINT__ */
