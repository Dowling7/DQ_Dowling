#ifdef __CINT__

#pragma link C++ class SQSlowCont+;

#endif /* __CINT__ */
