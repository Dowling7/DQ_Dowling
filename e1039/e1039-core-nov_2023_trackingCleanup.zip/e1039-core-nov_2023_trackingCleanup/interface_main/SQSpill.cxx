/*
 * SQSpill.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw
 */

#include "SQSpill.h"

using namespace std;

ClassImp(SQSpill);


