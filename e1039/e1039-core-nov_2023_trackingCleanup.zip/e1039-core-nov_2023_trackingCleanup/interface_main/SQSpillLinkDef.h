#ifdef __CINT__

#pragma link C++ class SQSpill+;

#endif /* __CINT__ */
