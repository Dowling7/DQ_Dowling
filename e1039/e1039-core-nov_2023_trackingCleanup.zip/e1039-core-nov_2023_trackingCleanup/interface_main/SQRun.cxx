/*
 * SQRun.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw
 */



#include "SQRun.h"

using namespace std;

ClassImp(SQRun)
