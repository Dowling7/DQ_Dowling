/*
 * SQStringMap.C
 */
#include "SQStringMap.h"

using namespace std;

ClassImp(SQStringMap)
