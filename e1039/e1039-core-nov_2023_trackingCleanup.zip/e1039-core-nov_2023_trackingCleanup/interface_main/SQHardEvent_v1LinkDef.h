#ifdef __CINT__

#pragma link C++ class SQHardEvent_v1+;

#endif /* __CINT__ */
