#include "SQDimuonVector.h"
//using namespace std;
ClassImp(SQDimuonVector)
