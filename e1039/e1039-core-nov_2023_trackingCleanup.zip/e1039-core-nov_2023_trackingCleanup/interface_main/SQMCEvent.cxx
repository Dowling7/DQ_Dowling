#include "SQMCEvent.h"
using namespace std;
ClassImp(SQMCEvent)

//void SQMCEvent::identify(std::ostream& os = std::cout) const
//{
//  cout << "---SQMCEvent::identify: abstract base-------------------" << endl;
//}

