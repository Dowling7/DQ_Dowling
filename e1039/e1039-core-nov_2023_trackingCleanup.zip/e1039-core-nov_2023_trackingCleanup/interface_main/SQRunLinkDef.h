#ifdef __CINT__

#pragma link C++ class SQRun+;

#endif /* __CINT__ */
