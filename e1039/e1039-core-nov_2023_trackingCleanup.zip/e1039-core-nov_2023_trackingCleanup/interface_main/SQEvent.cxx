/*
 * SQEvent.C
 *
 *  Created on: Oct 29, 2017
 *      Author: yuhw
 */



#include "SQEvent.h"

using namespace std;

ClassImp(SQEvent)
