#ifdef __CINT__

#pragma link C++ class SQCalMCHit_v1+;

#endif /* __CINT__ */