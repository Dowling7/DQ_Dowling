#ifdef __CINT__

#pragma link C++ class SQIntMap+;

#endif /* __CINT__ */
