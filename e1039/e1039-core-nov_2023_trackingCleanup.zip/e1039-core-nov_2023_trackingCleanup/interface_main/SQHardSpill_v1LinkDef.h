#ifdef __CINT__

#pragma link C++ class SQHardSpill_v1+;

#endif /* __CINT__ */
