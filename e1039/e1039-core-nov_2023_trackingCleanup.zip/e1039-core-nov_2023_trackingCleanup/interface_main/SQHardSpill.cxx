#include "SQHardSpill.h"
using namespace std;

ClassImp(SQHardSpill)
