#ifdef __CINT__

#pragma link C++ class SQTrack+;

#endif /* __CINT__ */
