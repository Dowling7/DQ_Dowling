#ifdef __CINT__

#pragma link C++ class SQHitVector+;

#endif /* __CINT__ */
