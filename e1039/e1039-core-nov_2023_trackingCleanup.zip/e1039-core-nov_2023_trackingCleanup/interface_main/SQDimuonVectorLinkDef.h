#ifdef __CINT__

#pragma link C++ class SQDimuonVector+;

#endif /* __CINT__ */
