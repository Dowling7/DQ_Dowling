#ifdef __CINT__

#pragma link C++ class PHGenEvent+;

#endif
