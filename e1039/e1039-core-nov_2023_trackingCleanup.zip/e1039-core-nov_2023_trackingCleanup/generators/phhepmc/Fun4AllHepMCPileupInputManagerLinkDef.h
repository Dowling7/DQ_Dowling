#ifdef __CINT__

#pragma link C++ class Fun4AllHepMCPileupInputManager-!;

#endif
