#ifdef __CINT__

#pragma link C++ class Fun4AllHepMCOutputManager-!;

#endif
