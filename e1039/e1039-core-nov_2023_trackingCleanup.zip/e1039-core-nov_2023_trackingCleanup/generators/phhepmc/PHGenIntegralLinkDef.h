#ifdef __CINT__

#pragma link C++ class PHGenIntegral+;

#endif
