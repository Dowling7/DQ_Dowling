#ifdef __CINT__

#pragma link C++ class std::vector<PHGenEventListV1::PHGenEventVersion>+;
#pragma link C++ class PHGenEventListV1+;

#endif /* __CINT__ */
