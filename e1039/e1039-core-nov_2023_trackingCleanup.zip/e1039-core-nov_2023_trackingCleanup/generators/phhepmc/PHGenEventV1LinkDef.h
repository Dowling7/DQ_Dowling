
#ifdef __CINT__

#pragma link C++ class HepMC::GenEvent-;
#pragma link C++ class PHGenEventV1+;

#endif
