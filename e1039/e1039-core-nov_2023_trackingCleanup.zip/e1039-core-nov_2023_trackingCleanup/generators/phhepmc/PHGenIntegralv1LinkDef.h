#ifdef __CINT__

#pragma link C++ class PHGenIntegralv1+;

#endif
