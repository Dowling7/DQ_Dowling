#ifdef __CINT__

#pragma link C++ class PHGenEventList+;

#endif /* __CINT__ */
