#ifdef __CINT__

#pragma link C++ class PHPythia8-!;
#pragma link C++ class PHPy8GenTrigger-!;
#pragma link C++ class PHPy8ParticleTrigger-!;

#endif
