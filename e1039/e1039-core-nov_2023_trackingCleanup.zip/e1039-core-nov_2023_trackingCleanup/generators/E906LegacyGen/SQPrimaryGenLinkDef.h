//
#ifdef __CINT__

#pragma link C++ class SQPrimaryParticleGen-!;
#pragma link C++ class SQPileupGen-!;

#endif
