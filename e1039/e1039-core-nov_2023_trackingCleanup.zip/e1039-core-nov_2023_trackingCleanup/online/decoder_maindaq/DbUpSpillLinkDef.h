#ifdef __CINT__

#pragma link C++ class DbUpSpill-!;

#endif /* __CINT__ */
