#ifdef __CINT__

#pragma link C++ class DbUpRun-!;

#endif /* __CINT__ */
