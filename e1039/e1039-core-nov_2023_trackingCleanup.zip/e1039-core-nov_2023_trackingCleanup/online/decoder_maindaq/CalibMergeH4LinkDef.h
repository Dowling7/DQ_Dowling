#ifdef __CINT__

#pragma link C++ class CalibMergeH4-!;

#endif /* __CINT__ */
