#ifdef __CINT__

#pragma link C++ class Fun4AllSpillDstOutputManager-!;

#endif /* __CINT__ */
