#ifdef __CINT__

#pragma link C++ class Fun4AllEVIOInputManager-!;

#endif /* __CINT__ */
