#ifdef __CINT__

#pragma link C++ class DecoStatusDb-!;

#endif /* __CINT__ */
