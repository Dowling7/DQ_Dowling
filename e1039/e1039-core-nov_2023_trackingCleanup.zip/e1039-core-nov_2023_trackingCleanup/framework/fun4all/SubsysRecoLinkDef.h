#ifdef __CINT__

#pragma link C++ class Fun4AllBase-!;
#pragma link C++ class SubsysReco-!;

#endif /* __CINT__ */



