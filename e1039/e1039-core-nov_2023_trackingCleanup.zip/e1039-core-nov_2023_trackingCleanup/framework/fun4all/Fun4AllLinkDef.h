#ifdef __CINT__

#pragma link C++ class Fun4AllDstInputManager-!;
#pragma link C++ class Fun4AllDstOutputManager-!;
#pragma link C++ class Fun4AllDummyInputManager-!;
#pragma link C++ class Fun4AllHistoManager-!;
#pragma link C++ class Fun4AllInputManager-!;
#pragma link C++ class Fun4AllNoSyncDstInputManager-!;
#pragma link C++ class Fun4AllOutputManager-!;
#pragma link C++ class Fun4AllServer-!;
#pragma link C++ class Fun4AllSyncManager-!;

#endif /* __CINT__ */
