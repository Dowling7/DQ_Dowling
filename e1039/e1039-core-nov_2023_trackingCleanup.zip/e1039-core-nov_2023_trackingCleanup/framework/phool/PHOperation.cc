//-----------------------------------------------------------------------------
//  $Header: /afs/rhic.bnl.gov/phenix/PHENIX_CVS/offline/framework/phool/PHOperation.C,v 1.3 2014/01/12 16:15:05 pinkenbu Exp $
//
//  The PHOOL's Software
//  Copyright (C) PHENIX collaboration, 1999
//
//  Implementation of class ...
//
//  Author: Matthias Messer
//-----------------------------------------------------------------------------
#include "PHOperation.h" 

template <class T> PHOperation<T>::PHOperation() 
{
}

template <class T> PHOperation<T>::~PHOperation() 
{
}

