#ifdef __CINT__

#include "phool.h"
#pragma link C++ enum PHMessageType;
#pragma link C++ enum PHAccessType;
#pragma link C++ enum PHTreeType;
#pragma link C++ function PHMessage(const std::string &, int, const std::string &);

#endif /* __CINT__ */
