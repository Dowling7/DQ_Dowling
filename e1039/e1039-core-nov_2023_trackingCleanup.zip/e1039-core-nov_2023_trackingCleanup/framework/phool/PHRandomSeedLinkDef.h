#ifdef __CINT__

#pragma link C++ class PHRandomSeed - !;

#endif /* __CINT__ */
