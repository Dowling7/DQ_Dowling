#ifdef __CINT__

#pragma link C++ class PHFlag - !;

#endif /* __CINT__ */
