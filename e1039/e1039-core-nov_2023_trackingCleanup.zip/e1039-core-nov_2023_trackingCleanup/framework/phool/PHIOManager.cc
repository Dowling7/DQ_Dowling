//-----------------------------------------------------------------------------
//
//  The PHOOL's Software
//  Copyright (C) PHENIX collaboration, 1999
//
//  Implementation of class PHIOManager
//
//  Author: Matthias Messer
//-----------------------------------------------------------------------------

#include "PHIOManager.h"

PHIOManager::PHIOManager():
  eventNumber(0)
{}
