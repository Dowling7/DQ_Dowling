#ifdef __CINT__

#pragma link C++ class PHObject + ;

#endif /* __CINT__ */
