#ifdef __CINT__

#pragma link C++ class FlagSave+;
#pragma link C++ class FlagSavev1+;
#pragma link C++ class RunHeader+;
#pragma link C++ class SyncObject+;
#pragma link C++ class SyncObjectv1+;
#pragma link C++ class SyncObjectv2+;
#pragma link C++ class EventHeader+;
#pragma link C++ class EventHeaderv1+;

#endif
