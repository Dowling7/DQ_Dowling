#ifdef __CINT__

#pragma link C++ class PHParameters-!;

#endif /* __CINT__ */
