#ifdef __CINT__

#pragma link C++ class PHParametersContainer-!;

#endif /* __CINT__ */
