#ifdef __CINT__

#pragma link C++ class PHParameterInterface-!;

#endif /* __CINT__ */
