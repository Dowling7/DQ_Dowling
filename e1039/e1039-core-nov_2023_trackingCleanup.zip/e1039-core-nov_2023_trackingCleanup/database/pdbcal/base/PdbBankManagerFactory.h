#ifndef __PdbBankManagerFactory_h__
#define __PdbBankManagerFactory_h__

#include "PHGenericFactoryT.h"
#include "PdbBankManager.h"

typedef PHGenericFactoryT<PdbBankManager> PdbBankManagerFactory;

#endif
