#include "PdbBankList.h"

PdbBankList::PdbBankList()
{
}

PdbBankList::~PdbBankList()
{
}

