//-----------------------------------------------------------------------------
//  $Header: /afs/rhic.bnl.gov/phenix/PHENIX_CVS/offline/database/pdbcal/base/PdbCalChan.cc,v 1.2 2008/06/01 01:25:35 pinkenbu Exp $
//
//  The pdbcal package
//  Copyright (C) PHENIX collaboration, 1999
//
//  Implementation of class PdbCalChan
//
//  Author: Matthias Messer
//-----------------------------------------------------------------------------
#include "PdbCalChan.h"

ClassImp(PdbCalChan);
