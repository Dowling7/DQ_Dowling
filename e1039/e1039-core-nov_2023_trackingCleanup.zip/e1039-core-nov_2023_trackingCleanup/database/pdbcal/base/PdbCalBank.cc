//  Implementaion of class PdbCalBank
//  Author: Matthias Messer

#include "PdbCalBank.h"

PdbCalBank::PdbCalBank()
{
}

PdbCalBank::~PdbCalBank()
{
}
