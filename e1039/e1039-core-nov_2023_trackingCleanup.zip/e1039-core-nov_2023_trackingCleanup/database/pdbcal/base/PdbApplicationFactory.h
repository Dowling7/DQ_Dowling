#ifndef __PdbApplicationFactory_h__
#define __PdbApplicationFactory_h__

#include "PHGenericFactoryT.h"
#include "PdbApplication.h"

typedef PHGenericFactoryT<PdbApplication> PdbApplicationFactory;

#endif
